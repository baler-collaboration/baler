# -*- coding: utf-8 -*-
from setuptools import setup

packages = \
['baler', 'baler.modules']

package_data = \
{'': ['*']}

install_requires = \
['awkward-pandas>=2022.12a1,<2023.0',
 'matplotlib>=3.6.2,<4.0.0',
 'pandas>=1.5.2,<2.0.0',
 'scikit-learn>=1.2.0,<2.0.0',
 'sklearn>=0.0.post1,<0.1',
 'torch>=1.13.0,<2.0.0',
 'tqdm>=4.64.1,<5.0.0',
 'uproot==4.2.2']

setup_kwargs = {
    'name': 'baler',
    'version': '0.1.0',
    'description': 'Baler aims to be a tool which will use lossy machine learning based compression methods to compress multi-dimensional data and evaluate the accuracy of the compressed data. The compression “algorithm” is derived by training an auto-encoder to compress and decompress multidimensional data.',
    'long_description': '# Run\n\nThis is a really rough readme.\n\nWhat --mode=train now does is that it trains a given model (where the model name is currently defined in the config file). The training is the same as before, and the model parameters (officially called the state dictionary) is now saved together. Can be ran via:\n\n`python baler --config=projects/cms/configs/cms.json --input=projects/cms/data/cms_data.root --output=projects/cms/output/ --mode=train`\n\nwhich will, most importantly, output: current_model.pt . This contains all necessary model parameters.\n\nTo do something with this model, you can now choose --mode=compress, which can be ran as\n\n`python baler --config=projects/cms/configs/cms.json --input=projects/cms/data/cms_data.root --output=projects/cms/output/ --model=projects/cms/output/current_model.pt --mode=compress`\n\nThis will output a compressed file called compressed.pickle, and this is the latent space representation of the input dataset. It will also output cleandata_pre_comp.pickle which is just the exact data being compressed.\n\nTo decompress the compressed file, we choose --mode=decompress and run:\n\n`python baler --config=projects/cms/configs/cms.json --input=projects/cms/output/compressed.pickle --output=projects/cms/output/ --model=projects/cms/output/current_model.pt --mode=decompress`\n\nwhich outputs decompressed.pickle . To double check the file sizes, we can run\n\n`python baler --config=projects/cms/configs/cms.json --input=projects/cms/output/ --output=projects/cms/output/ --mode=info`\n\nwhich will print the file sizes of the data we’re compressing, the compressed dataset & the decompressed dataset.\n\nPlotting works as before, with a minor caveat. This caveat is that the column names are currently manually implemented because I couldn’t find a simple way to store the column names (there is a good explanation for this), so it will not run immediately on the UN dataset without modifications to the config file. Plotting would look something like this however:\n\n`python baler --config=projects/cms/configs/cms.json --input=projects/cms/output/cleandata_pre_comp.pickle --output=projects/cms/output/decompressed.pickle --mode=plot`\n',
    'author': 'Your Name',
    'author_email': 'you@example.com',
    'maintainer': 'None',
    'maintainer_email': 'None',
    'url': 'None',
    'packages': packages,
    'package_data': package_data,
    'install_requires': install_requires,
    'python_requires': '>=3.8,<4.0',
}


setup(**setup_kwargs)
